/**
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) Bao Project and Contributors. All rights reserved.
 */

/* THIS CONFIG IS DEFINED FOR TESTING PURPOSES ONLY */

#include <config.h>

VM_IMAGE(baremetal_6, "/home/mafs/TRICORE/bao-baremetal-guest/bins/baremetal6.bin")
VM_IMAGE(baremetal_7, "/home/mafs/TRICORE/bao-baremetal-guest/bins/baremetal7.bin") //TODO

struct config config = {

        .hyp.base_addr = 0x80000000,
        .shmemlist_size = 1,
        .shmemlist = (struct shmem[]) {
            [0] = { .size = 0x00001000, .place_phys = true, .phys = 0x90070000}
        },

        .vmlist_size = 2,

        .vmlist = (struct vm_config[]){
            {       
                .image = {
                        .base_addr = 0x70000000, //TODO
                        .load_addr = VM_IMAGE_OFFSET(baremetal_7),
                        .size = VM_IMAGE_SIZE(baremetal_7),
                },

                .entry = 0x70000000, //TODO

                .platform = {
                        .cpu_num = 1,
                        .region_num = 1,
                        .regions = (struct vm_mem_region[]){
                            {
                                .base = 0x70000000, //TODO
                                .size = 0x20000 //TODO
                            }
                        },
                        .ipc_num = 1,
                        .ipcs = (struct ipc[]) {
                            {
                                .base = 0x90070000,
                                .size = 0x00001000,
                                .shmem_id = 0,
                                .interrupt_num = 1,
                                .interrupts = (irqid_t[]) {1360}
                            }
                        },
                        .dev_num = 3,
                        .devs = (struct vm_dev_region[]){
                            { //TIMER
                                .pa = 0xF8800000,
                                .va = 0xF8800000,
                                .size = 0x1000,
                                .interrupt_num = 1,
                                .interrupts = (irqid_t[]) {10},
                            },
                            {   //Ports 13 and 14 base is 13, 0x400 for each port
                                .pa = 0xF003D400,
                                .va = 0xF003D400,
                                .size = 0x800,
                            },
                            {
                                .pa = 0xF46C0000,
                                .va = 0xF46C0000,
                                .size = 0x200,
                            }
                        }
                        //TODO Interrupts and devs
                }
            },
            {       
                .image = {
                        .base_addr = 0x60000000, //TODO
                        .load_addr = VM_IMAGE_OFFSET(baremetal_6),
                        .size = VM_IMAGE_SIZE(baremetal_6),
                },

                .entry = 0x60000000, //TODO

                .platform = {
                        .cpu_num = 1,
                        .region_num = 1,
                        .regions = (struct vm_mem_region[]){
                            {
                                .base = 0x60000000, //TODO
                                .size = 0x20000 //TODO
                            }
                        },
                        .ipc_num = 1,
                        .ipcs = (struct ipc[]) {
                            {
                                .base = 0x90070000,
                                .size = 0x00001000,
                                .shmem_id = 0,
                                .interrupt_num = 1,
                                .interrupts = (irqid_t[]) {1361}
                            }
                        },
                        /*.dev_num = 1,
                        .devs = (struct vm_dev_region[]){
                            { //TIMER
                                .pa = 0xF8840000,
                                .va = 0xF8840000,
                                .size = 0x1000,
                                .interrupt_num = 1,
                                .interrupts = (irqid_t[]) {26},
                            },
                        }*/
                }
            }
        },

};
