/**
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) Bao Project and Contributors. All rights reserved.
 */

/* THIS CONFIG IS DEFINED FOR TESTING PURPOSES ONLY */

#include <config.h>

VM_IMAGE(baremetal_9, "/home/mafs/TRICORE/bao-baremetal-guest/bins/baremetal9.bin") //TODO

struct config config = {

        .vmlist_size = 1,
        .hyp.base_addr = 0x80000000,

        .vmlist = (struct vm_config[]){
            {       
                .image = {
                        .base_addr = 0x90080000, //TODO
                        .load_addr = VM_IMAGE_OFFSET(baremetal_9),
                        .size = VM_IMAGE_SIZE(baremetal_9),
                },

                .entry = 0x90080000, //TODO

                .platform = {
                    .cpu_num = 1,
                    .region_num = 1,
                    .regions = (struct vm_mem_region[]){
                        {
                            .base = 0x90080000, //TODO
                            .size = 0x80000 //TODO
                        }
                    },
                    .dev_num = 3,
                    .devs = (struct vm_dev_region[]){
                        { //TIMER
                            .pa = 0xF8800000,
                            .va = 0xF8800000,
                            .size = 0x1000,
                            .interrupt_num = 1,
                            .interrupts = (irqid_t[]) {10},
                        },
                        {   //Ports 13 and 14 base is 13, 0x400 for each port
                            .pa = 0xF003D400,
                            .va = 0xF003D400,
                            .size = 0x800,
                        },
                        { //UART
                            .pa = 0xF46C0000,
                            .va = 0xF46C0000,
                            .size = 0x200,
                        }
                    },
                    .arch = {
                        .gspr_num = 1,
                        .gspr_groups = (unsigned long int[]){1},
                    }
                }
            },
        },

};
